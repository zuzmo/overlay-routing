class HelloMessageHandler

	def self.handle_received(parsed_msg)
		# do nothing
	end

end